import java.util.ArrayList;
import java.util.List;

public class LZW {

    private int dictionarySize;
    private String[] dictionary;

    public LZW() {
        initializeDictionary();
    }

    private void initializeDictionary() {
        dictionarySize = 256;
        dictionary = new String[4096]; // Maximum dictionary size (2^12)
        for (int i = 0; i < dictionarySize; i++) {
            dictionary[i] = "" + (char) i;
        }
    }

    public List<Integer> compress(String input) {
        List<Integer> compressedData = new ArrayList<>();
        String current = "";
        for (char symbol : input.toCharArray()) {
            String next = current + symbol;
            if (findIndex(next) != -1) {
                current = next;
            } else {
                compressedData.add(findIndex(current));
                dictionary[dictionarySize++] = next;
                current = "" + symbol;
            }
        }
        if (!current.isEmpty()) {
            compressedData.add(findIndex(current));
        }
        return compressedData;
    }

    private int findIndex(String str) {
        for (int i = 0; i < dictionarySize; i++) {
            if (dictionary[i] != null && dictionary[i].equals(str)) {
                return i;
            }
        }
        return -1;
    }

    public String decompress(List<Integer> compressed) {
        initializeDictionary(); // Rebuild dictionary for decompression
        StringBuilder decompressed = new StringBuilder();
        int previousCode = compressed.remove(0);
        decompressed.append(dictionary[previousCode]);
        for (int code : compressed) {
            String entry;
            if (dictionary[code] != null) {
                entry = dictionary[code];
            } else if (code == dictionarySize) {
                entry = dictionary[previousCode] + dictionary[previousCode].charAt(0);
            } else {
                throw new IllegalArgumentException("Invalid compressed data");
            }
            decompressed.append(entry);
            dictionary[dictionarySize++] = dictionary[previousCode] + entry.charAt(0);
            previousCode = code;
        }
        return decompressed.toString();
    }

    public static void main(String[] args) {
        LZW lzw = new LZW();
        String input = "THIS IS MY LZW IMPLEMENTATION";
        List<Integer> compressed = lzw.compress(input);
        System.out.println("Compressed: " + compressed);
        String decompressed = lzw.decompress(compressed);
        System.out.println("Decompressed: " + decompressed);
    }
}
