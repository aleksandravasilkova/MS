import java.math.BigDecimal;
import java.math.MathContext;
import java.util.HashMap;
import java.util.Map;

public class ArithmeticCoding {

    public static void main(String[] args) {
        String original = "THIS IS MY ENCODING";
        System.out.println("Original: " + original);

        Map<Character, Integer> frequencies = calculateFrequencies(original);
        Map<Character, BigDecimal[]> intervals = buildIntervals(frequencies);

        BigDecimal encoded = arithmeticEncode(original, intervals);
        System.out.println("Encoded: " + encoded);

        String decoded = arithmeticDecode(encoded, original.length(), intervals);
        System.out.println("Decoded: " + decoded);

        if (!original.equals(decoded)) {
            throw new RuntimeException("Decoded data does not match original data");
        }
    }

    // Calculate frequencies of each character in the input text
    private static Map<Character, Integer> calculateFrequencies(String text) {
        Map<Character, Integer> frequencies = new HashMap<>();
        for (char c : text.toCharArray()) {
            frequencies.put(c, frequencies.getOrDefault(c, 0) + 1);
        }
        return frequencies;
    }

    // Build intervals for each character based on frequencies
    private static Map<Character, BigDecimal[]> buildIntervals(Map<Character, Integer> frequencies) {
        Map<Character, BigDecimal[]> intervals = new HashMap<>();
        BigDecimal total = BigDecimal.valueOf(frequencies.values().stream().mapToInt(Integer::intValue).sum());
        BigDecimal low = BigDecimal.ZERO;

        for (Map.Entry<Character, Integer> entry : frequencies.entrySet()) {
            char c = entry.getKey();
            int freq = entry.getValue();
            BigDecimal high = low.add(BigDecimal.valueOf(freq).divide(total, MathContext.DECIMAL128));
            intervals.put(c, new BigDecimal[]{low, high});
            low = high;
        }

        return intervals;
    }

    // Perform arithmetic encoding using intervals
    private static BigDecimal arithmeticEncode(String text, Map<Character, BigDecimal[]> intervals) {
        BigDecimal low = BigDecimal.ZERO;
        BigDecimal high = BigDecimal.ONE;

        for (char c : text.toCharArray()) {
            BigDecimal[] interval = intervals.get(c);
            BigDecimal range = high.subtract(low);
            high = low.add(range.multiply(interval[1]));
            low = low.add(range.multiply(interval[0]));
        }

        return low.add(high).divide(BigDecimal.valueOf(2), MathContext.DECIMAL128);
    }

    // Perform arithmetic decoding using intervals
    private static String arithmeticDecode(BigDecimal encoded, int length, Map<Character, BigDecimal[]> intervals) {
        StringBuilder decodedText = new StringBuilder();
        BigDecimal low = BigDecimal.ZERO;
        BigDecimal high = BigDecimal.ONE;

        for (int i = 0; i < length; i++) {
            BigDecimal range = high.subtract(low);
            BigDecimal value = encoded.subtract(low).divide(range, MathContext.DECIMAL128);

            for (Map.Entry<Character, BigDecimal[]> entry : intervals.entrySet()) {
                char c = entry.getKey();
                BigDecimal[] interval = entry.getValue();
                if (interval[0].compareTo(value) <= 0 && value.compareTo(interval[1]) < 0) {
                    decodedText.append(c);
                    high = low.add(range.multiply(interval[1]));
                    low = low.add(range.multiply(interval[0]));
                    break;
                }
            }
        }

        return decodedText.toString();
    }
}
